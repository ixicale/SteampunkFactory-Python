# Solicitudes de rates

Api que guarda en un CSV los response de la Api

## resp/
Carpeta donde se almacenan los CSV por defecto

## properties.txt

Archivo que tiene la lista de todas las propiedades a iterar

## requests.txt

Archivo que tiene la lista de request o payloads de la api. Ejecuta por cada linea 53 semanas apartir desde las fechas travelBegin y travelEnd

## Requisitos

Instalar requests y ejecutar el archivo con python

`pip install -r requirements.txt`

`python multi-post.py`
